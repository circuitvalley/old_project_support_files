#pragma config OSC = HS, OSCS = OFF
#pragma config PWRT= OFF , BOR=ON, BORV = 45
#pragma config WDT = OFF
#pragma config DEBUG = OFF ,LVP =OFF , STVR =OFF         // CONFIGURATION BIT SETTING

#include <p18f458.h>

void spi(unsigned char);             //SPI Function To send the data

void delayMs(int x);                     // to generate some delay

void main()                                  // main program starts here
{
	SSPSTAT =0x40;              // Configure SSPSTAT  for transmission occur from idle to active clock and Buffer flag =0
	SSPCON1=0x22;              //Configure  SSPCON1 for ENABLE SERIAL PORT
                                            //         and disable general I/O pin ,, SPI master clock= Fosc/64
 	TRISC=0;                          //Configure PORT C as output ,,
                                                 //    we are only sending the data so we do't need to set SPI pin as input

		while(1)                      // loop for ever so that led keep repeating that pattern
		{
		spi(0x01);                   // send 01 hex to the SPI port it will glow the first led

		delayMs(1000);          // wait for approximate 1sec   ,
                                               //      if we do't give the delay then led will flash to fast that
                                               //      we can't even know when it glow and when it off

		spi(0x02);                   //send 02 hex to the SPI port it will glow the send led   ,
                                              //       if you want to glow both led same time send 03 hex and so  on
		delayMs(1000);           // wait for 1 sec
		}

}

void spi(unsigned char myData)
{
SSPBUF = myData;                    // put the data in the SSPBUF register which going to be send
while(!SSPSTATbits.BF);           // wait until the all bits sended
}



void delayMs(int x)              // a general delay function
{
int i;
	for (x ;x>0;x--)
	{
	for (i=0;i<=110;i++);
	}
}
/*#pragma config OSC = HS, OSCS = OFF
#pragma config PWRT= OFF , BOR=ON, BORV = 45
#pragma config WDT = OFF
#pragma config DEBUG = OFF ,LVP =OFF , STVR =OFF
#include <p18f458.h>
void spi(unsigned char);
void delayMs(int x);
void main()
{
	SSPSTAT =0x40;
	SSPCON1=0x22;
	TRISC=0;
	PORTCbits.RC2=0;
		while(1)
		{
		spi(0x01);
		delayMs(1000);
		spi(0x02);
		delayMs(1000);
		}

}

void spi(unsigned char myData)
{
SSPBUF = myData;
while(!SSPSTATbits.BF);
}

void delayMs(int x)
{
int i;
	for (x ;x>0;x--)
	{
	for (i=0;i<=110;i++);
	}
}


*/