#ifndef __lcd16_h_
#define __lcd16_h_

#include <htc.h>

#define clk GPIObits.GP0        //change these values if you want to chage the pins
#define data GPIObits.GP1

void integerToLcd(int integer );
void gotoXy(unsigned char  ,unsigned char );
void lcdInit(void);
void lcdCmd(unsigned char);
void lcdData(unsigned char);
void lcdWriteNibble(unsigned char);
void waitLcd(int);
void waitUs(int);
void prints(const char * message);
#endif