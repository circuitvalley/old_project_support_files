// programmer :Gaurav Chaudhary
// www.circuitValley.com
//Compiler :HI-TECH C For pic10/12/16 mcu V9.82


#include <htc.h>
#include "lcd16.h" 


 __CONFIG (FOSC_INTRCIO & MCLRE_OFF & BOREN_ON & CP_OFF & CPD_OFF & WDTE_OFF ); 

void main()
{

CMCON=0x7;
ANSEL =0x00;
TRISIO=0xC;

GPIO=0;
lcdInit();
gotoXy(3,0);
prints("Hello Word");
gotoXy(3,1);
prints("Serial LCD");
while(1)
{

}
}
