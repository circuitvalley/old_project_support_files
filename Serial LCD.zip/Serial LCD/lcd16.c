#include "lcd16.h"

unsigned char rs;
void lcdWriteNibble(unsigned char d)
{
unsigned char i;
clk = 0;
data= 0;
for(i=0;i<8;i++)
	{	
	waitUs(10);
	clk = 1;
	waitUs(10);
	clk = 0;
	waitUs(10);
	}
				
data = 1;					//set Q7= 1 for E
waitUs(10);
clk =1;
waitUs(10);
clk=0;
waitUs(10);

data = rs;				//set Q6 for RS 
waitUs(10);
clk =1;
waitUs(10);
clk =0;
waitUs(10);

	for ( i=8;i>0;i=i>>1)
	{
		if(d & i)
			{
				data =1;
			}
			else
			{
				data =0;
			}
		waitUs(10);
		clk = 1;
		waitUs(10);
		clk = 0;
	}

data=0;			//shift Q0
waitUs(10);
clk = 1;
waitUs(10);
clk = 0;
waitUs(10);

data = 1;		//now send enable 
waitUs(100);
data = 0;
}


void lcdCmd(unsigned char byte)
{
rs=0; //because sending command

lcdWriteNibble(byte>>4);
waitUs(100);
lcdWriteNibble(byte & 0xF);



}

void lcdData(unsigned char byte)
{

rs=1;  //because sending data

lcdWriteNibble(byte>>4);
waitUs(100);
lcdWriteNibble(byte & 0xF);


}

void lcdInit(void)
{
rs=0;
waitLcd(40);
lcdWriteNibble(0x3);
waitLcd(5);
lcdWriteNibble(0x3);
waitLcd(5);
lcdWriteNibble(0x3);
waitLcd(2);
lcdWriteNibble(0x2);

lcdCmd(0x28);   //set data length 4 bit 2 line
waitLcd(250); 
lcdCmd(0x0C);   // set display on cursor oFF blink off to on the cursor E to and on the blink F
waitLcd(250);
lcdCmd(0x01); // clear lcd 
waitLcd(250);
lcdCmd(0x06);  // cursor shift direction
waitLcd(250);
lcdCmd(0x80);  //set ram address
waitLcd(250);
}

void waitLcd(int x)
{
unsigned char i;
for (x ;x>1;x--)
{
for (i=0;i<=110;i++);
}
}

void waitUs(int x)
{
unsigned char i ;
for (x ;x>1;x--)
{
for (i=0;i<=10;i++);
}
}


void gotoXy(unsigned char  x,unsigned char y)
{
 if(x<40)
 {
  if(y) x|=0b01000000;
  x|=0b10000000;
  lcdCmd(x);
  }
}





void prints(const char * message){	// Write message to LCD (C string type)
lcdCmd(0x8); // disable display;
		while (*message){			// Look for end of string
					lcdData(*message++);
					}
	lcdCmd(0xE); // enable display;
	}




void integerToLcd(int integer )   //this routine will print any int to lcd directly 
{
	//	Break down the original number into the thousands, hundreds, tens,
	//	and ones places and then immediately write that value to the LCD
unsigned char thousands	,hundreds,tens,ones;
thousands = integer / 1000;
	
    lcdData(thousands + 0x30);
	
	 hundreds = ((integer - thousands*1000)-1) / 100;

	lcdData( hundreds + 0x30);
tens=(integer%100)/10;	

	lcdData( tens + 0x30);
	ones=integer%10;

	lcdData( ones + 0x30);
}


void clearLcd(void)
{
	//	Send command to LCD (0x01)
	lcdCmd(0x01);	
}

