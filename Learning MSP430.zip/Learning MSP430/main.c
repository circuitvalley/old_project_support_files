
#include <msp430g2211.h>

void main(void)
{
//code goes here
volatile unsigned int i;
WDTCTL = WDTPW + WDTHOLD;         //Stop watchdog timer
P1DIR = 0xFF;            // P1.0 output (LED red)
P1OUT = 0;          // LED off
/////BCSCTL3 |= LFXT1S_2;     // LFXT1 =	 VLO
//IFG1 &= ~OFIFG;            // Clear OSCFault flag
//__bis_SR_register(SCG1 + SCG0);      // Stop DCO
//BCSCTL2 |= SELM_3 + DIVM_3;        // MCLK = VLO/8

// P1SEL = P1SEL | BIT0 |BIT4;  uncomment this line if you want aclk to out at p1.0
P1OUT = 0x00;
P1OUT ^= BIT6;
//TACTL = 0x0126;

while(1)
{

//	while ((TACTL & TAIFG) ==0){
//	}
		//	TACTL &=~TAIFG;
			P1OUT ^= BIT0;


			P1OUT ^= BIT6;
			for(i=0;i<=30000;i++);

}
}
